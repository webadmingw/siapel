<?php require_once 'header.php'; ?>
<div class="container">
    <?php require_once $view; ?>
</div>
<?php require_once 'footer.php'; ?>
